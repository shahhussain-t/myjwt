exports.homePage=(req,res)=>{
    res.send("<h1>Deploying Node js sucesufully  Elastic Beanstalk</h1>")
}