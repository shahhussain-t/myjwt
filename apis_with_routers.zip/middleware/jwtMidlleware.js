const jwt=require("jsonwebtoken")


const secretKey="sheraz"



const jwtAuthorzation={

    sign(payload){

        const token=jwt.sign(payload,secretKey)
        return token
    }





}


module.exports=jwtAuthorzation