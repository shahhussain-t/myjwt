const express=require('express')
const homerouter=express.Router()

const {homePage}=require("../controller/homepageController.js")




homerouter.get("/",homePage)



module.exports=homerouter